from distutils.core import setup

setup(
		name		=	'nester',
		version		=	'1.4.0',
		py_modules	=	['nester'],
		author		=	'yrh',
		author_email=	'yangruihan@vip.qq.com',
		url			=	'http://www.yangruihan.com',
		description =	'A simple printer of nested lists',
	 )
