﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Experiment.Models
{
    public class MovieDBContext: DbContext
    {
        public DbSet<Movie> Movies { get; set; }
    }

    public class Movie
    {
        public int ID { get; set; }      //电影编号

        [Display(Name="电影名称")]
        [Required(ErrorMessage ="必填")]
        [StringLength(60, MinimumLength =3, ErrorMessage ="电影名必须是[3, 60]个字符")]
        public string Title { get; set; }     //电影名称

        [Display(Name ="上映时间")]
        [Required(ErrorMessage ="必填")]
        [DataType(DataType.Date, ErrorMessage ="上映时间必须形如：2000/1/1")]
        public DateTime ReleaseDate { get; set; }    //上映时间

        [Display(Name ="电影类型")]
        [Required(ErrorMessage = "必填")]
        public string Genre { get; set; }      //电影类型

        [Display(Name ="电影票价")]
        [Required(ErrorMessage = "必填")]
        [Range(30, 200, ErrorMessage ="电影票价应在[30, 200]之间")]
        [DataType(DataType.Currency, ErrorMessage ="电影票价必须为数字且在[30, 200]之间")]
        public decimal Price { get; set; }    //电影票价

        [Display(Name ="电影分级")]
        [Required(ErrorMessage = "必填")]
        [StringLength(5, ErrorMessage ="请填写正确的电影评级信息")]
        public string Rating { get; set; }     //电影分级

    }
}