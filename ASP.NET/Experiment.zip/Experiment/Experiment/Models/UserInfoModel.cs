﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Experiment.Models
{
    public class UserInfoModel
    {
        public string username { set; get; } // 用户名
        public string password { set; get; } // 密码
        public string gender { set; get; } // 性别
        public string nativePlace { set; get; } //籍贯
        public string city { set; get; } // 城市
        public string Email { set; get; } // E-mail
        public string phoneNumber { set; get; }// 手机号码
        public string speciality { set; get; } // 专业擅长
        public List<string> hobby { set; get; } //爱好
        public string photo { set; get; } //照片
        public string birthday { set; get; } //生日
        public string remark { set; get; } //备注 
    }
}