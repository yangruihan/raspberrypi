﻿using Experiment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Experiment.Controllers
{
    public class Experiment3Controller : Controller
    {
        private MovieDBContext db = new MovieDBContext();

        // GET: Experiment3
        public ActionResult Index()
        {
            return View(db.Movies.ToList());
        }

        public ActionResult Create()
        {
            Movie movie = new Movie();
            movie.Price = 100;
            movie.Rating = "无";
            movie.Genre = "科幻";
            movie.ReleaseDate = DateTime.Parse("2015-01-01");
            movie.Title = "黑客帝国";
            db.Movies.Add(movie);
            db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}